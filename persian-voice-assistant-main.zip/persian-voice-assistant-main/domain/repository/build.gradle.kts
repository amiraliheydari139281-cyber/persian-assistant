// domain/repository - Repository interfaces

plugins {
    id("java-library")
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

dependencies {
    api(project(":domain:model"))
    api("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0")
}